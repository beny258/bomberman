
package bomberman;

/**
 *
 * @author David Benes
 */
public enum BombType {
    BASIC, LARGE;
}
