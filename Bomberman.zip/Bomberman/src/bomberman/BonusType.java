
package bomberman;

/**
 *
 * @author David Benes
 */
public enum BonusType {
    BOOTS, EXTRALIFE, LARGEBOMB;
}
