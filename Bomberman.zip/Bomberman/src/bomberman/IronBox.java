
package bomberman;

/**
 *
 * @author David Benes
 */
class IronBox extends MapObject {
    
    public IronBox(int posX, int posY) {
        super(posX, posY);
    }

}
