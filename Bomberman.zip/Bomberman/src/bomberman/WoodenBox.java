
package bomberman;

/**
 *
 * @author David Benes
 */
class WoodenBox extends MapObject {
    
    public WoodenBox(int posX, int posY) {
        super(posX, posY);
    }

}
